﻿namespace techBar.Data.Services
{
    public class EntityBaseRepository
    {
    }
}