﻿namespace techBar.Data.Base
{
    public interface IEntityBase
    {
        int Id { get; set; }
    }
}
