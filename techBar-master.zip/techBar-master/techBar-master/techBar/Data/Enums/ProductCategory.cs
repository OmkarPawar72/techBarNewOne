﻿namespace techBar.Data.Enums
{
    public enum ProductCategory
    {
        ComputerAccessories,
        CellPhoneAccessories,
        CameraAccessories,
        Wearable,
        HomeAccessories
    }
}
